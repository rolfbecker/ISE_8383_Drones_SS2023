var namespace_a_d_c__settings =
[
    [ "ADC_REGS_t", "struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html", "struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t" ]
];