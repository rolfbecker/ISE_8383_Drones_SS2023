var _a_d_c__util_8h =
[
    [ "getConversionEnumStr", "_a_d_c__util_8h.html#ab6104e4e363b1fecb3b9158ee8bee37b", null ],
    [ "getSamplingEnumStr", "_a_d_c__util_8h.html#ab07f137e89f16be8bfb6e05c8bba8905", null ],
    [ "getStringADCError", "_a_d_c__util_8h.html#a0414ae3ca07a90b40e0515956ca0e49d", null ],
    [ "averages_list", "_a_d_c__util_8h.html#a307171b253b7da9afe30eb6c2588d34b", null ],
    [ "conversion_speed_list", "_a_d_c__util_8h.html#afb6703ab0983fe02a0c5de9d771c0757", null ],
    [ "resolutions_list", "_a_d_c__util_8h.html#a1f7a8c6dcdadcb5dd43a77de9a380bb0", null ],
    [ "sampling_speed_list", "_a_d_c__util_8h.html#ad813ee6b28ef93d8bc7d0c3bf62b967b", null ]
];