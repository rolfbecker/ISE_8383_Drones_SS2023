var searchData=
[
  ['temp_5fsensor_109',['TEMP_SENSOR',['../namespace_a_d_c__settings.html#a8c2a64f3fca3ac6b82e8df8cf44f6ca2a2d8001cb5670d5668694dbf8697ee69f',1,'ADC_settings']]],
  ['trim_110',['trim',['../namespace_v_r_e_f.html#adf9a5a3b3d7140ad45019141c2f054b4',1,'VREF']]]
];
