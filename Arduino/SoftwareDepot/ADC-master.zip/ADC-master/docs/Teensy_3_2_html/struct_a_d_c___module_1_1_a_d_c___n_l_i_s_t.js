var struct_a_d_c___module_1_1_a_d_c___n_l_i_s_t =
[
    [ "pin", "struct_a_d_c___module_1_1_a_d_c___n_l_i_s_t.html#a1b635b49b8a53b9b5355af40be1455c9", null ],
    [ "sc1a", "struct_a_d_c___module_1_1_a_d_c___n_l_i_s_t.html#a3169dfd9150d30c4c5cc8459659099aa", null ]
];