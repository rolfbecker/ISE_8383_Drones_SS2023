var searchData=
[
  ['ref_5f1v2_274',['REF_1V2',['../namespace_a_d_c__settings.html#a5f42fd9e070e88475ec7cee39bbf4f8da77f9ecbcb2044013c35ce1156c14b3a0',1,'ADC_settings']]],
  ['ref_5f3v3_275',['REF_3V3',['../namespace_a_d_c__settings.html#a5f42fd9e070e88475ec7cee39bbf4f8dacbdca6103ed9d1895ad7cabeda125dac',1,'ADC_settings']]],
  ['ref_5fext_276',['REF_EXT',['../namespace_a_d_c__settings.html#a5f42fd9e070e88475ec7cee39bbf4f8da5f3cc7cfab06012c0aa6a4b8a5a77161',1,'ADC_settings']]]
];
