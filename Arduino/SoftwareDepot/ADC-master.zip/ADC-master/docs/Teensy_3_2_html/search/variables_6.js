var searchData=
[
  ['sampling_5fspeed_5flist_244',['sampling_speed_list',['../namespace_a_d_c__util.html#ad813ee6b28ef93d8bc7d0c3bf62b967b',1,'ADC_util']]],
  ['savedcfg1_245',['savedCFG1',['../struct_a_d_c___module_1_1_a_d_c___config.html#a54092156c81d6dc11b521faf791751f6',1,'ADC_Module::ADC_Config']]],
  ['savedcfg2_246',['savedCFG2',['../struct_a_d_c___module_1_1_a_d_c___config.html#ab1fc8559f2f2f9b9fc0c77a9e67ff2a6',1,'ADC_Module::ADC_Config']]],
  ['savedsc1a_247',['savedSC1A',['../struct_a_d_c___module_1_1_a_d_c___config.html#a708e83c3bbd11a06d88802b8941e19a8',1,'ADC_Module::ADC_Config']]],
  ['savedsc2_248',['savedSC2',['../struct_a_d_c___module_1_1_a_d_c___config.html#a9f2fc51728d47cd8f6e8b00e8f400296',1,'ADC_Module::ADC_Config']]],
  ['savedsc3_249',['savedSC3',['../struct_a_d_c___module_1_1_a_d_c___config.html#ae04df65edae35a9beaaec59ce39b1e9e',1,'ADC_Module::ADC_Config']]],
  ['sc1a2channeladc0_250',['sc1a2channelADC0',['../class_a_d_c.html#aa3fc624721f8108ef8b77b45a857bdc6',1,'ADC']]],
  ['sc1a2channeladc1_251',['sc1a2channelADC1',['../class_a_d_c.html#ad1ed91f3ef9e283133455802c37c6501',1,'ADC']]]
];
