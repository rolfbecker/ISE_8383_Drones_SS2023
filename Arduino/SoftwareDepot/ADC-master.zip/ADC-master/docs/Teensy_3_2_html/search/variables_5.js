var searchData=
[
  ['resolutions_5flist_241',['resolutions_list',['../namespace_a_d_c__util.html#a1f7a8c6dcdadcb5dd43a77de9a380bb0',1,'ADC_util']]],
  ['result_5fadc0_242',['result_adc0',['../struct_a_d_c_1_1_sync__result.html#aa523cf5b3ed9823c0ff672a4b8eb3f4e',1,'ADC::Sync_result']]],
  ['result_5fadc1_243',['result_adc1',['../struct_a_d_c_1_1_sync__result.html#a652c42a16111d4edeb3cd7b324b382c7',1,'ADC::Sync_result']]]
];
