var searchData=
[
  ['readsingle_82',['readSingle',['../class_a_d_c.html#aee7423bfcbb03465bb0bd1e3c6474452',1,'ADC::readSingle()'],['../class_a_d_c___module.html#a60d0edc82fd1dbb2e20d090a53718ce2',1,'ADC_Module::readSingle()']]],
  ['readsynchronizedcontinuous_83',['readSynchronizedContinuous',['../class_a_d_c.html#acd10f3bc117a244e70e53c3489aa97bc',1,'ADC']]],
  ['readsynchronizedsingle_84',['readSynchronizedSingle',['../class_a_d_c.html#a38d941542bbdbc20c1b9e26a5051094a',1,'ADC']]],
  ['recalibrate_85',['recalibrate',['../class_a_d_c___module.html#afe8ed6f2a6c811ec3ef2c4aba768982f',1,'ADC_Module']]],
  ['ref_5f1v2_86',['REF_1V2',['../namespace_a_d_c__settings.html#a5f42fd9e070e88475ec7cee39bbf4f8da77f9ecbcb2044013c35ce1156c14b3a0',1,'ADC_settings']]],
  ['ref_5f3v3_87',['REF_3V3',['../namespace_a_d_c__settings.html#a5f42fd9e070e88475ec7cee39bbf4f8dacbdca6103ed9d1895ad7cabeda125dac',1,'ADC_settings']]],
  ['ref_5fext_88',['REF_EXT',['../namespace_a_d_c__settings.html#a5f42fd9e070e88475ec7cee39bbf4f8da5f3cc7cfab06012c0aa6a4b8a5a77161',1,'ADC_settings']]],
  ['reseterror_89',['resetError',['../class_a_d_c.html#aa65014de31051e06a469982ca286496b',1,'ADC::resetError()'],['../class_a_d_c___module.html#abf980784cf468d28fc2cbb94d06be500',1,'ADC_Module::resetError()']]],
  ['resolutions_5flist_90',['resolutions_list',['../namespace_a_d_c__util.html#a1f7a8c6dcdadcb5dd43a77de9a380bb0',1,'ADC_util']]],
  ['result_5fadc0_91',['result_adc0',['../struct_a_d_c_1_1_sync__result.html#aa523cf5b3ed9823c0ff672a4b8eb3f4e',1,'ADC::Sync_result']]],
  ['result_5fadc1_92',['result_adc1',['../struct_a_d_c_1_1_sync__result.html#a652c42a16111d4edeb3cd7b324b382c7',1,'ADC::Sync_result']]]
];
