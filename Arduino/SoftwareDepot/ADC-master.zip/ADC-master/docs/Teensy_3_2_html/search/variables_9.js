var searchData=
[
  ['sampling_5fspeed_5flist_319',['sampling_speed_list',['../namespace_a_d_c__util.html#ad813ee6b28ef93d8bc7d0c3bf62b967b',1,'ADC_util']]],
  ['savedcfg1_320',['savedCFG1',['../struct_a_d_c___module_1_1_a_d_c___config.html#a54092156c81d6dc11b521faf791751f6',1,'ADC_Module::ADC_Config']]],
  ['savedcfg2_321',['savedCFG2',['../struct_a_d_c___module_1_1_a_d_c___config.html#ab1fc8559f2f2f9b9fc0c77a9e67ff2a6',1,'ADC_Module::ADC_Config']]],
  ['savedsc1a_322',['savedSC1A',['../struct_a_d_c___module_1_1_a_d_c___config.html#a708e83c3bbd11a06d88802b8941e19a8',1,'ADC_Module::ADC_Config']]],
  ['savedsc2_323',['savedSC2',['../struct_a_d_c___module_1_1_a_d_c___config.html#a9f2fc51728d47cd8f6e8b00e8f400296',1,'ADC_Module::ADC_Config']]],
  ['savedsc3_324',['savedSC3',['../struct_a_d_c___module_1_1_a_d_c___config.html#ae04df65edae35a9beaaec59ce39b1e9e',1,'ADC_Module::ADC_Config']]],
  ['sc1a_325',['SC1A',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#adcdaa8ff38cbddbd4bf81d540faae943',1,'ADC_settings::ADC_REGS_t']]],
  ['sc1a2channeladc0_326',['sc1a2channelADC0',['../class_a_d_c.html#a4377c680975fe754de24b8f8617042de',1,'ADC']]],
  ['sc1b_327',['SC1B',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#a107ddc8e41350e07f7b47b14f1d4993d',1,'ADC_settings::ADC_REGS_t']]],
  ['sc2_328',['SC2',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#ab2a9de0ab1d13efdde3a9539d0e6b2e8',1,'ADC_settings::ADC_REGS_t']]],
  ['sc3_329',['SC3',['../struct_a_d_c__settings_1_1_a_d_c___r_e_g_s__t.html#a5ff03875c8e196054d26c5459d706166',1,'ADC_settings::ADC_REGS_t']]]
];
