var class_ring_buffer_d_m_a =
[
    [ "RingBufferDMA", "class_ring_buffer_d_m_a.html#a37b578fe20ec7e7a361a614f9e9a2a07", null ],
    [ "~RingBufferDMA", "class_ring_buffer_d_m_a.html#ae7b0ff5b6789ac462a657602dbedc7c4", null ],
    [ "buffer", "class_ring_buffer_d_m_a.html#ac83104910c4245a4ef7e4fbe61eaf777", null ],
    [ "isEmpty", "class_ring_buffer_d_m_a.html#a0c10d34a151d2b9960e2ae58084e5baa", null ],
    [ "isFull", "class_ring_buffer_d_m_a.html#a52f974a38148e4baab0acbd2edb5c0e0", null ],
    [ "read", "class_ring_buffer_d_m_a.html#ac79ee944ee98c4da859c6e5f112022ea", null ],
    [ "size", "class_ring_buffer_d_m_a.html#a3d61386b92bd89064fca9f847cd16c58", null ],
    [ "start", "class_ring_buffer_d_m_a.html#ae534ef51326ce3123dc118bc201d59d1", null ],
    [ "write", "class_ring_buffer_d_m_a.html#ac64de99b9ef9b4c1b1ae36444ce37699", null ],
    [ "b_end", "class_ring_buffer_d_m_a.html#a738e6dc1618b83178f42638cd9b58662", null ],
    [ "b_start", "class_ring_buffer_d_m_a.html#a1145aff44d38f6c8025f28bf082ec8b0", null ],
    [ "dmaChannel", "class_ring_buffer_d_m_a.html#a289ca5377bb36f35f87127ce9719cbb7", null ],
    [ "p_elems", "class_ring_buffer_d_m_a.html#adf857179fa7ae20d8b439ee5794dc4c2", null ]
];